# pitchdetection (maestro)

Audio-first violin pitch analyzer. Produces a teacher- or judge-friendly Markdown report from a scale recording, identifying wrong notes (wrong pitch class) and intonation drift (cents off from the expected note).

Built around CREPE pitch tracking + DTW alignment to an expected scale.

## Quick start

Requires Python 3.12+, ffmpeg, and ~1 GB disk for `torch` + CREPE weights.

```bash
# create env (using uv; standard venv works too)
uv venv
uv pip install -r requirements.txt

# audio-only run (no scale → just intonation drift)
.venv/bin/python audio_v0.py path/to/recording.m4a

# with scale alignment → adds wrong-note detection
.venv/bin/python audio_v0.py path/to/recording.m4a --scale "G3 major asc-desc 2oct"
```

Accepts `.wav`, `.mp3`, `.m4a`, `.flac`, `.aiff` directly, and `.mp4` / `.mov` via `ffmpeg`.

## Output

A per-note table with detected pitch, expected pitch (when `--scale` is given), cents deviation, and verdict, plus an accuracy summary:

```
  #   start     end       Hz  detected    cents  expected  verdict
------------------------------------------------------------------
  1    0.14    0.81    262.5        C4     +5.9        C4  OK
  4    1.65    2.28    319.4       D#4    +45.6        E4  WRONG
 13    6.29    6.85    593.5        D5    +18.1        D5  OFF
 ...
Summary: 29 voiced notes, 7 flat/sharp (|cents| > 15), 5 wrong-note
Accuracy: 58.6%
```

Verdicts:
- `OK` — within ±15¢ (configurable via `--threshold`)
- `OFF` — right pitch class, off by more than threshold cents
- `WRONG` — wrong pitch class entirely (only when `--scale` given)
- `unvoiced` — silence/breath

## Scale specification

```
--scale "G3 major asc-desc 2oct"     # tonic[octave], mode, pattern, # octaves
--scale "G major"                    # defaults: tonic octave 4, asc only, 1 octave
--scale "G3 A3 B3 C4 D4 E4 F#4 G4"   # explicit space-separated note list
```

Modes: `major`, `minor`, `harmonic_minor`, `melodic_minor`, `dorian`, `mixolydian`, `chromatic`.

## Pipeline

```
input.{wav,mp4,...}
  ├─ ffmpeg → mono 22050Hz wav
  ├─ CREPE → continuous pitch curve + periodicity
  ├─ librosa onset_detect → note window boundaries
  ├─ per-window: median pitch (skipping attack transient)
  ├─ octave-error correction (>7 semitones from both neighbors → try ±12)
  ├─ same-note merge (collapse over-segmented onsets)
  ├─ DTW align to expected scale (when --scale given)
  └─ per-note table + summary
```

## Claude Code skill

A `maestro` skill ships in [`skill/SKILL.md`](./skill/SKILL.md). It teaches Claude Code how to drive `audio_v0.py`, ask the right questions about scale and audience, and turn the raw table into a teacher-style or audition-style report.

Install:
```bash
mkdir -p ~/.claude/skills/maestro
cp skill/SKILL.md ~/.claude/skills/maestro/SKILL.md
```

Then invoke `/maestro` in any Claude Code session.

## Architecture & roadmap

See [`DESIGN.md`](./DESIGN.md) for the full multi-modal design (audio + vision + VLM coaching), capability map, and current gaps.

## Limitations

- Monophonic only — double-stops will confuse pitch tracking
- Equal-temperament reference — just-intonation evaluation will look off in predictable ways
- No vibrato or dynamics analysis yet
- No vision side yet (bow geometry, posture, finger placement)
