---
name: maestro
description: Use when the user wants to analyze a violin (or other monophonic instrument) recording and produce a readable pitch/intonation report — for a violin teacher giving feedback to a student, or a judge assessing a youth-symphony audition. Triggers on phrases like "analyze violin", "check intonation", "audition feedback", "scale analysis", "violin report", "pitch report", "is this in tune". Operates on .wav/.mp3/.m4a/.mp4/.mov files.
version: 0.1.0
---

# maestro

Audio-first violin recording analyzer. Produces a teacher- or judge-friendly Markdown report from a scale recording. Powered by CREPE pitch tracking + DTW scale alignment.

## When to use

The user has a recording of someone playing a scale (or short passage) on violin and wants a structured assessment, suitable for:
- A teacher returning feedback to a student
- A youth-symphony audition evaluation
- Self-review before a lesson or audition

## Tools

- Script: `~/Documents/maestro/audio_v0.py`
- Env: `~/Documents/maestro/.venv/` (uv-managed; librosa, numpy, torch, torchcrepe)

If either is missing, halt and tell the user — torchcrepe pulls ~1GB of deps; ask before installing.

## Workflow

### 1. Gather context (ask before running)

- **Input file path** — audio (.wav/.mp3/.m4a/.flac/.aiff) or video (.mp4/.mov; ffmpeg extracts the audio)
- **Scale played** — tonic (with octave), mode, pattern (asc / desc / asc-desc), # of octaves
  - If the user can't say, run without `--scale`. You still get pitch-only analysis (intonation drift only, no wrong-note detection).
- **Audience** — choose report tone:
  - **Teacher → student**: warm, specific, action-oriented (default)
  - **Audition assessment**: objective, structured, scoring-friendly
  - **Self-review**: same as teacher but blunter

### 2. Run the analyzer

```
~/Documents/maestro/.venv/bin/python ~/Documents/maestro/audio_v0.py <file> [--scale "<spec>"] [--threshold <cents>]
```

Scale-spec forms:
- Mode: `"G3 major asc-desc 2oct"` — `<tonic[octave]> <mode> [asc|desc|asc-desc] [Noct]`
- Modes: `major`, `minor` (natural), `harmonic_minor`, `melodic_minor` (asc form), `dorian`, `mixolydian`, `chromatic`
- Explicit notes: `"G3 A3 B3 C4 D4 E4 F#4 G4"`

Default threshold is ±15¢. Don't change it just to make the score look better — it's a reporting knob.

### 3. Read the raw output

The script emits a per-note table: `# | start | end | Hz | detected | cents | expected | verdict`

Verdicts:
- `OK` — within threshold
- `OFF` — right pitch class, off by more than threshold cents
- `WRONG` — wrong pitch class entirely (only when `--scale` given)
- `unvoiced` — silence/breath, ignore

Plus a summary: total voiced notes, # flat/sharp, # wrong-note, accuracy %.

### 4. Build the report

Convert the table into a Markdown report with these sections (skip a section if it has nothing real to say — don't pad):

**Header**
```
# Violin Pitch Report — <filename>
- Recording: <duration>s
- Notes detected: <N> (vs. <M> expected)
- Scale: <human description, e.g. "G major, 2 octaves up and down">
```

**Headline** (one or two sentences)
- Crisp count: "X within tolerance, Y intonation drift, Z wrong notes"
- If median cents-deviation across stable notes is ≥3¢ in one direction, attribute it to **tuning, not playing** — say so explicitly. The violin is probably tuned slightly off A=440. Don't blame the player for a uniform offset.

**What went well**
2–3 bullets pointing at the cleanest stretch (e.g., "ascending B4 → G5 was steady within ±10¢"). Omit if there's genuinely nothing to praise.

**Wrong notes** (when `--scale` was given)
One bullet per WRONG row, with timestamp, played-vs-expected, and a *cautious* one-line technical hypothesis a teacher might offer (string crossing, half-step finger placement, missed accidental). Don't speculate beyond what the data supports — if the cause is unclear, just describe what happened.
```
- 0:01.6 — D#4 instead of E4 (about a semitone flat). First-finger placement on the D string.
```

**Intonation drift** (the OFF rows)
Group by pattern when one exists ("D5 was sharp both times it appeared — possibly third-finger placement on the A string"). Otherwise list with timestamp and cents.

**Patterns to address** (synthesis across the table)
- Same note repeated, same direction off → finger habit
- Errors cluster at register changes (high vs. low) → position-shift issue
- Errors cluster at scale-degree boundaries (e.g., always the leading tone) → tuning concept
- These are *hypotheses* until vision data is available. Frame as "consider checking..."

**Overall**
- Accuracy %: notes within tolerance / total
- For audition reports, add: max deviation, # wrong notes, scale completeness (notes detected vs. expected)

### 5. Tone and length

- Teacher report: 250–500 words, warm, specific, ends with 1–2 concrete practice suggestions
- Audition report: 150–300 words, neutral and objective, lead with the numeric summary
- Self-review: same length as teacher, blunter

After printing the report inline, **offer to save** it to `~/Documents/maestro/reports/<filename>-<YYYY-MM-DD>.md`. Don't save without asking.

## Common pitfalls

- **Wrong scale tonic** — DTW will mis-align and flag many false WRONG notes. Symptom: the "expected" column gets stuck on one note for many rows. Ask the user to verify the scale before reporting.
- **Systematic ±5¢ bias** — almost always tuning, not playing. Note once at the top, don't flag on every row.
- **First/last unvoiced rows** — usually breath or bow lift; don't list as problems.
- **Onset over-segmentation** — the script already merges duplicate-onset slivers (`raw → cleanup` in the output). Trust the cleanup count, not raw.
- **CREPE startup** — first run takes 5–10s extra (model load + JIT). Don't worry about this; mention it only if user asks why it's slow.

## Limitations (be upfront)

- **Monophonic only** — double-stops will confuse the pitch tracker.
- **Equal-temperament reference** — for just-intonation evaluation the cents numbers will look off in predictable ways (sharp leading tones, flat thirds in major).
- **No vibrato/dynamics** yet.
- **No vision side** — cannot directly comment on bow angle, posture, finger position. Inferences from pitch patterns only.
- Roadmap is in `~/Documents/MAESTRO-DESIGN-101.md`.
